# 결과 출처 (MovieLens 1M, 과제 4)

- 데이터: https://files.grouplens.org/datasets/movielens/ml-1m.zip  (SHA-256 506d64ca44484487c11dc2d9a28de5c54948213e6b96285e298afe28d6ea4e0f, v1과 같은 파일: True)
- v1 실행: 1차 노트북. 원본 결과는 `archive_v1/`에 수정 없이 보관. CMS v1(선형 해시) 결과는 보관만 하며 본 결과에 사용하지 않음.
- v2 실행: 이 노트북. CPU Intel(R) Xeon(R) CPU @ 2.20GHz, RAM 12.67 GB (`environment_v2.json`).

| 파일 | 내용 | 출처 |
|---|---|---|
| bloom_v1.csv, bloom_summary_v1.csv, bloom_v1_fpr_overview.csv | Bloom 정확도·파라미터 15개 | v1 |
| bloom_saturation_v1.csv | Bloom 포화 실험 | v1 |
| timing_v1_bloom_set.csv | Bloom·Set 처리시간 (같은 v1 런타임) | v1 |
| cms_v2.csv, cms_v2_frequency_bands.csv | CMS v2 원자료 (설정·시드별) | v2 |
| cms_v2_summary.csv, cms_v2_equal_memory.csv, cms_v2_depth_effect.csv, cms_v2_frequency_band_summary.csv | CMS v2 요약 | v2 |
| cms_hash_collision_check.csv, cms_prehash_injectivity.json | CMS 해시 검증 | v2 |
| baseline_v2.json, timing_v2_cms_dictionary.csv | 파싱·Dictionary·CMS 처리시간 (같은 v2 런타임) | v2 |
| memory_comparison.csv | getsizeof 추정 / 배열 저장 공간 / tracemalloc(v1만) / 이론 참고값 구분 | v1 + v2 + 계산 |
| decision_summary_final.json | 판정 요약 | v1 + v2 |
| figures/ | 핵심 그래프 6개 | v1 + v2 |

- 서로 다른 런타임의 처리시간은 직접 비교하지 않는다.
- CMS 대표 설정 (2719, 5)만 시드 3개, 시간 3회 측정. 나머지 8개는 시드 42, 시간 1회 측정(탐색적 비교용).
- 판정 기준(Bloom FPR 1%, CMS 고빈도 상대오차 5%·Top-100 95%)은 실험용 가정이며 산업 표준이 아니다.
